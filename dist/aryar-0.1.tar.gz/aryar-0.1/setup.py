from setuptools import setup, find_packages

setup(
    name='aryar',
    version='0.1',
    packages=['aryar'],
    install_requires=['requests']
)
